                   Explore weather Trends

In this project, you will analyze local and global temperature data and compare the temperature trends where you live to overall global temperature trends.

The Database Schema:
There are three tables in the database:

1)city_list - This contains a list of cities and countries in the database. Look through them in order to find the city nearest to you.
2)city_data - This contains the average temperatures for each city by year (ºC).
3)global_data - This contains the average global temperatures by year (ºC).


Tools:
  SQL
  Excel