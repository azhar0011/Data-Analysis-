                 investigate-a-dataset-template

Project Details:

In this project, you will analyze a dataset and then communicate your findings about it. You will use the Python libraries NumPy, pandas, and Matplotlib to make your analysis easier.

Data
The Movie Database in page: https://www.kaggle.com/tmdb/tmdb-movie-metadata.

Tools:
python