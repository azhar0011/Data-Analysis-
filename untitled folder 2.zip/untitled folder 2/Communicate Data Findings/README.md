                  Communicate Data Findings

Project Details:

- The data found from here: https://www.lyft.com/bikes/bay-wheels/system-data
- This dataset is from the Ford GoBike System data with 519700 elements bikes in this dataset.
- contains columns(duration, start time, end time, start station id, start station name,end station id, end station name, user type, member birth year, member gender, bike share for all trip...etc) 


### Data wrangling for this dataset consisted combining the 12 months worth of datasets into dataset and skips of several the unnecessary columns.

# My goal was find any relationship of columns
so after cleaning the data , in visualization data is divided the plot to three type
1)Univariate Exploration and Analysis:only one random column
2)Bivariate Exploration and Analysis:two column
3)Multivariate Exploration and Analysis: having or involving a number of independent mathematical or statistical variables.

## For the presentation I focus on the main variable trip duration. 
- 1)slide showing how the first visualistion needed a log transformation
- 2)find the trend Gender of Users
- 3) The Age Distribution of users
- 4)The Trend of Duration Trips in Month
- 5) Trip Duration in minute with Month and Gender
- 6)Conclusion- 3) The Age Distribution of users\n",

Dataset:
https://www.lyft.com/bikes/bay-wheels/system-data

Tools:
python